<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ResetOtp extends Model
{
    protected $guarded = [];
}
