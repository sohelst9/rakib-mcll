<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BattlePaymentDetails extends Model
{
    protected $guarded = [];
}
