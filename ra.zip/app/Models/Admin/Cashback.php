<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class Cashback extends Model
{
    protected $guarded = [];
}
